#pragma once
class Cue
{
public:
	Cue();
	virtual ~Cue();
};

