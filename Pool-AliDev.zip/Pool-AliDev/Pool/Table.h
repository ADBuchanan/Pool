#pragma once
class Table
{
public:
	Table();
	virtual ~Table();
};

