#pragma once
class Collisions
{
public:
	Collisions();
	virtual ~Collisions();
};

