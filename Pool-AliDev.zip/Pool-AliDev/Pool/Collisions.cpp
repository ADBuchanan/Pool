#include "Collisions.h"



Collisions::Collisions()
{
}


Collisions::~Collisions()
{
}
